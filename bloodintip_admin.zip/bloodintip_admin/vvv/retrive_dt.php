<html>
<head>
<title>Firebase App</title>
</head>
<body>
<div class= "main-div" aligns="left">
<h3>All Student</h3>

<table  border ="1">
   <thead>
        <tr>
           <td>Name</td>
           <td>Phone</td>
           <td>Action</td>
        </tr>
   </thead>
       <tbody id="tabledt">
           <!-- <tr>
           <td>Subhashree Jena</td>
           <td>8093738350</td>
           <td><button>Remove</button></td>
           
           </tr>

           <tr>
           <td>Chitra Rekha</td>
           <td>78789798778</td>
           <td><button>Remove</button></td>
           
           </tr>

           <tr>
           <td>Milan Krushna </td>
           <td>8745454312</td>
           <td><button>Remove</button></td>
           
           </tr> -->
       </tbody>




</table>
</div>

<script src="https://www.gstatic.com/firebasejs/4.8.1/firebase.js"></script>
<script>
  // Initialize Firebase
  var config = {
    apiKey: "AIzaSyCOC7AlHkiew92-jYNUPlPdinowEQuIwMQ",
    authDomain: "my-app-1ed82.firebaseapp.com",
    databaseURL: "https://my-app-1ed82.firebaseio.com",
    projectId: "my-app-1ed82",
    storageBucket: "my-app-1ed82.appspot.com",
    messagingSenderId: "874673758559"
  };
  firebase.initializeApp(config);
</script>

<script src="https://code.jquery.com/jquery-1.12.4.js"></script>


<script src="retriv.js"></script>
</body>

</html>