
<html>
<head>



<title>
Registration form

</title>

</head>    
    
  <body>
    <div class="container">
    <div class="row"> 
     <h3>Registration form</h3>
    <form  id="registr">

    <div class="form-group">
     <label for="fname">Id</label>
     <input type="text" name="u_id" id="u_id" class="form-control" placeholder="Enter your name">
     </div>


    <div class="form-group">
     <label for="fname">Name</label>
     <input type="text" name="name" id="fname" class="form-control" placeholder="Enter your name">
     </div>

     <div class="form-group">
     <label for="femail">Email</label>
     <input type="text" name="email" id="femail" class="form-control" placeholder="Enter your email">
     </div>


     <div class="form-group">
     <label for="fphone">Phone</label> 
     <input type="number" name="phone" id="fphone" class="form-control" placeholder="Enter your phone">
     </div>

     <div class="form-group">
     <label for="fphone">Message</label>
     <input type="text" name="message" id="fmessage" class="form-control" placeholder="Enter your message"><br> 
    </div>
 
    </form>
    <button id="submit" type="button" class="btn btn-primary" onclick= "formsubmit();" >Submit</button> <br>
    <button id="submit" type="button" class="btn btn-primary" onclick= "formupdate();" >Update</button> <br>
    <button id="submit" type="button" class="btn btn-primary" onclick= "formdelete();" >Delete</button> <br>
    
    
    
    </div>
    </div>

    <table  id="tabledata" border ="1">
  
        <tr>
          <td>User ID</td>
          <td>Name</td>
           <td>Email</td>
           <td>Phone</td>
           <td>Message</td>
           
        </tr>
  
</table>


    </body>




<script src="https://www.gstatic.com/firebasejs/4.8.1/firebase.js"></script>
<script>
  // Initialize Firebase
  var config = {
    apiKey: "AIzaSyDM7TzVlyJE074ngRpdwDMaH5hHRCPfBa0",
    authDomain: "registration-1a7ba.firebaseapp.com",
    databaseURL: "https://registration-1a7ba.firebaseio.com",
    projectId: "registration-1a7ba",
    storageBucket: "",
    messagingSenderId: "936360312128"
  };
  firebase.initializeApp(config);


</script>

<script src="https://code.jquery.com/jquery-1.12.4.js"></script>

<script src="sign_up.js"></script>


</html>