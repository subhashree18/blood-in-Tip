
<html>
<head>



<title>
Edit Donor Details

</title>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/css/bootstrap.min.css">

</head>    
    
  <body>
    <div class="container">
    <div class="col-md-6">
     <h3>Edit Donor Details</h3>
    <form  id="registr">



    <div class="form-group">
     <label for="fname">Name</label>
     <input type="text" name="name" id="fname" class="form-control" placeholder="Enter your name">
     </div>

     <div class="form-group">
     <label for="femail">Mobile</label>
     <input type="text" name="phone" id="fphone" class="form-control" placeholder="Enter your phone">
     </div>


     <div class="form-group">
     <label for="fphone">Blood group</label>
     <input type="text" name="fblood" id="fblood" class="form-control" placeholder="Enter your blood group">
    </div>

    <div class="form-group">
     <label for="fphone">Age</label>
     <input type="text" name="age" id="age" class="form-control" placeholder="Enter your age">
    </div>

    <div class="radio">
     <label for="fphone">Male</label> 
     <input type="radio" name="gendr" id="male" value="MALE">
     </div>

     <div class="radio">
     <label for="fphone">Female</label> 
     <input type="radio" name="gendr" id="female"value="FEMALE">
     </div>
  
    <div class="form-group">
  <label for="comment">Address:</label>
  <textarea class="form-control" name="address" id="address" rows="5" id="comment"></textarea>
</div>
 
    </form>
    <button id="submit_frm" type="button" class="btn btn-primary"  >Update</button> 
    
    
    
   </div>
    </div>

    

    </body>



    <script src="https://www.gstatic.com/firebasejs/4.8.2/firebase.js"></script>
    <script>
      // Initialize Firebase
      var config = {
        apiKey: "AIzaSyDEIyc8Bhj9St2BZV0Zmi5nvzwbAs4aqno",
        authDomain: "bloodintip.firebaseapp.com",
        databaseURL: "https://bloodintip.firebaseio.com",
        projectId: "bloodintip",
        storageBucket: "",
        messagingSenderId: "16342465035"
      };
      firebase.initializeApp(config);   
    </script>
    <!-- <script src="state_bloodgrp.js"></script> -->
    
    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>


    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/js/bootstrap.min.js" ></script>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>


<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>



<?php 

$donor_state = $_GET['dnr_st'];
$donor_listing = $_GET['dnr_lst'];

$ID = $_GET['u_Id'];


?>

<script>



var databaseRef = firebase.database().ref('Donor/<?php echo $donor_state.'/'.$donor_listing.'/'.$ID;?>/');

//var databaseRef = firebase.database().ref('Donor/Odisha/AB+/-L1Bx9E2vLUGK1o_hChu/'); 


databaseRef.on('value', gotdata);
    

function gotdata(data){

var dnr_dt = data.val();

console.log(dnr_dt);


// databaseRef.on('value', function(data){
       
//        var dnr_dt = data.val();

// console.log(dnr_dt);
//    });

var name = dnr_dt.name;
var mobile_no = dnr_dt.mobile_no;
var gender = dnr_dt.gender;
var donor_age = dnr_dt.donor_age;
var bloodgroup = dnr_dt.bloodgroup;
var address = dnr_dt.address;

 $("#fname").val(name);
 $("#fphone").val(mobile_no);
$("#fblood").val(bloodgroup);
$("#age").val(donor_age);
$("#address").val(address);


if(gender == 'MALE'){ 
$('#male').click();

}else{

    $('#female').click();

}



}

$('#submit_frm').click(function(){

//    alert('halo');

var uni_ky = '<?php echo $ID;?>' 

var radioValue = $("input[name='gendr']:checked").val();
            // if(radioValue){
            //     alert("Your are a - " + radioValue);
            // }

var get_dt = {

 name : $('#fname').val(),
 mobile_no : $('#fphone').val(),
 donor_age : $('#age').val(),
 bloodgroup : $('#fblood').val(),
 address : $('#address').val(),
 gender : radioValue
 

}

var updates = { };
     updates['Donor/<?php echo $donor_state.'/'.$donor_listing.'/'.$ID;?>' ] = get_dt;
    firebase.database().ref().update(updates);

    alert('Updated');

});


</script>



</html>