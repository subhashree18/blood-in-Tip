<html>
<head>
<title>
Firebase Web Project

</title>

</head>    
    
  <body>
    
    <div class="main-div">
     <h3>Firebase Web </h3>
       <textarea id="newmsg" name="message" placeholder=" Enter message" ></textarea>
    <button id="submit" type="button" onclick= "submitbtn();" >Submit</button>
    
    
    </div>
  
  
<script src="https://www.gstatic.com/firebasejs/4.8.1/firebase.js"></script>
<script>
  // Initialize Firebase
  var config = {
    apiKey: "AIzaSyCOC7AlHkiew92-jYNUPlPdinowEQuIwMQ",
    authDomain: "my-app-1ed82.firebaseapp.com",
    databaseURL: "https://my-app-1ed82.firebaseio.com",
    projectId: "my-app-1ed82",
    storageBucket: "my-app-1ed82.appspot.com",
    messagingSenderId: "874673758559"
  };
  firebase.initializeApp(config);
</script>

<script src="index1.js"></script>
  
  
  </body>  
    
 
</html>