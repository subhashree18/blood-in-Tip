var tableuser = document.getElementById("tabledtl");
var databaseRef = firebase.database().ref('Donor');


      databaseRef.once('value', function(snapshot) {
        snapshot.forEach(function(childSnapshot) {
          var childKey = childSnapshot.key;
         // var childData = childSnapshot.val();
          
         console.log(childKey);
         
         $("#tabledtl").append("<tr><td>" + childKey + "</td><td><a href='http://rayvil.com/firebase/donor_name.php?donor_name=" + childKey + " target='_blank'>View</a></td></tr>");

        //   var row = tableuser.insertRow(rowIndex);

        //   var cellId = row.insertCell(0);
        //   cellId.appendChild(document.createTextNode(childKey));
        
        //   rowIndex = rowIndex + 1;








        });
      
    
    });
     
     