//window.alert("helo");
var newmsg = document.getElementById("newmsg");
var submit  = document.getElementById("submit");
var heading = document.getElementById("firebasehead");

// var headingRef = firebase.database().ref().child("Heading");

// headingRef.on('value', function(headsnapshot) {

//     heading.innerText = headsnapshot.val();

// });

function submitbtn(){

//window.alert("hello");

var database = firebase.database().ref();

//console.log(database);

var setmsg = newmsg.value;

//var resdata = database.child("Text").set(setmsg);
var resdata = database.push().set(setmsg);

//console.log(resdata);


}