// var tableuser = document.getElementById("tabledata");
 var databaseRef = firebase.database().ref('Student/');

// var rowIndex = 1;

// console.log(databaseRef);

// databaseRef.once('value', function(snapshot) {
    

//     snapshot.forEach(function(childSnapshot) {
//         //alert('sdj');
//        // console.log(childSnapshot);


//       var childKey = childSnapshot.key;
//       var childData = childSnapshot.val();
//       var childEmail = childSnapshot.val();
//       var childPhone = childSnapshot.val();
//       var childMsg = childSnapshot.val();
     
//     //   console.log(childKey);
//     //   console.log(childData);
//     //   console.log(childEmail);
//     //   console.log(childPhone);
//     //   console.log(childMsg);
     

//       var row = tableuser.insertRow(rowIndex);
//       var cellId = row.insertCell(0);
//       var cellName = row.insertCell(1);
//       var cellEmail = row.insertCell(2);
//       var cellPhone = row.insertCell(3);
//       var cellMessage = row.insertCell(4);

//       cellId.appendChild(document.createTextNode(childKey));
//       cellName.appendChild(document.createTextNode(childData.st_name));
//       cellEmail.appendChild(document.createTextNode(childEmail.st_email));
//       cellPhone.appendChild(document.createTextNode(childPhone.st_phone));
//       cellMessage.appendChild(document.createTextNode(childMsg.st_message));

//       rowIndex = rowIndex + 1;

    


//     });
//   });
  
databaseRef.on("child_added" ,snap => {

   // console.log(snap.val());
    
     var id = snap.child("user_id").val();
     var name = snap.child("st_name").val();
     var email = snap.child("st_email").val();
     var phone = snap.child("st_phone").val();
     var message = snap.child("st_message").val();
    
     $("#tabledata").append("<tr><td>" + id + "</td><td>" + name + "</td><td>" + email + "</td><td>" + phone + "</td><td>" + message + "</td></tr>");
    
    });


function formsubmit(){
    var setname = document.getElementById("fname").value;
    var setemail = document.getElementById("femail").value;
     
     var setphone = document.getElementById("fphone").value;
    var setmessage = document.getElementById("fmessage").value;

    var uniqky = firebase.database().ref().child("Student").push().key;
    

//     //console.log(database);
  
    
//     databaseRef.push().set(setname);
//     databaseRef.push().set(setemail);
//     databaseRef.push().set(setphone);
//     databaseRef.push().set(setmessage);

 var all_dt = {
     
    user_id:uniqky,  
    st_name: setname,
    st_email:setemail,
    st_phone:setphone,
    st_message:setmessage,
    

 }

 var updates = { };
 updates['/Student/' + uniqky ] =all_dt;
 firebase.database().ref().update(updates);

 alert('created');

 //reload_page();

}

function formupdate(){

  
     
    var user_id =document.getElementById("u_id").value;
    var setname = document.getElementById("fname").value;
    var setemail = document.getElementById("femail").value;
     
     var setphone = document.getElementById("fphone").value;
    var setmessage = document.getElementById("fmessage").value;
    
    // var user_id = user_id.value;
    // var setname = nameuu.value;
    // var setemail = email.value;
    //  var setphone = phone.value;
    // var setmessage = message.value;
    

    var all_dt = {
     
        user_id:user_id,  
        st_name: setname,
        st_email:setemail,
        st_phone:setphone,
        st_message:setmessage,
        
    
     }
    
     var updates = { };
     updates['/Student/' + user_id ] =all_dt;
    firebase.database().ref().update(updates);
    
     alert('Updated');

     reload_page();

}

function formdelete(){

    var u_id =document.getElementById("u_id");

    var user_id = u_id.value;

    firebase.database().ref().child('/Student/' + user_id).remove();
    alert('Deleted');

    reload_page();


}

function reload_page(){

    window.location.reload();

}
