//window.alert("helo");

var retriveRef = firebase.database().ref().child("Student");

retriveRef.on("child_added" ,snap => {

console.log(snap.val());

 var name = snap.child("name").val();
 var phone = snap.child("phone").val();

 $("#tabledt").append("<tr><td>" + name + "</td><td>" + phone + "</td><td><button>Remove</button></td></tr>");

});

// databaseRef.on("child_added" ,snap => {

//     console.log(snap.val());
    
//      var id = snap.child("st_id").val();
//      var name = snap.child("st_name").val();
//      var email = snap.child("st_email").val();
//      var phone = snap.child("st_phone").val();
//      var message = snap.child("st_message").val();
    
//      $("#tabledata").append("<tr><td>" + id + "</td><td>" + name + "</td><td>" + email + "</td><td>" + phone + "</td><td>" + message + "</td></tr>");
    
//     });