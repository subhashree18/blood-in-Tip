<html>
   <head>
   <title>
    Blood In Tip
   </title>

   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/css/bootstrap.min.css">


  



   </head>
<body>
      <div class="container">
      <h2 class = "heading">Donor List</h2>
     <table id="tabledtl" border="1" class="table" >
        
        <tr class="success">

        <td><b>Sl No.</b></td>
        <!-- <td><b>Id</b></td> -->
        <td><b>Name</b></td>
        <td><b>Mobile</b></td>
        <td><b>Gender</b></td>
        <td><b>Age</b></td>
        <td><b>Blood Group</b></td>
        <td><b>Address</b></td>
        <td><b>Action</b></td>

      </tr>
     
     </table>
   </div>

</body>


</html>







<script src="https://www.gstatic.com/firebasejs/4.8.2/firebase.js"></script>
<script>
  // Initialize Firebase
  var config = {
    apiKey: "AIzaSyDEIyc8Bhj9St2BZV0Zmi5nvzwbAs4aqno",
    authDomain: "bloodintip.firebaseapp.com",
    databaseURL: "https://bloodintip.firebaseio.com",
    projectId: "bloodintip",
    storageBucket: "",
    messagingSenderId: "16342465035"
  };
  firebase.initializeApp(config);   
</script>
<!-- <script src="state_bloodgrp.js"></script> -->

<script src="https://code.jquery.com/jquery-1.12.4.js"></script>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/js/bootstrap.min.js" ></script>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>


<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>


<?php 
$donor_state = $_GET['donor_state'];
$donor_listing = $_GET['donor_name'];

?>

<script>

//alert('<?php echo $donor_listing;?>');

var tableuser = document.getElementById("tabledtl");
var databaseRef = firebase.database().ref('Donor/<?php echo $donor_state.'/'.$donor_listing;?>/');

var cunt = 0;

      databaseRef.once('value', function(snapshot) {
        snapshot.forEach(function(childSnapshot) {
          var childKey = childSnapshot.key;
          var childData = childSnapshot.val();
         

         ///var uniq_id = childkey;

          
////var clickfun = 'onclick="dnir_delete("'+childKey+'")"';

var clickfun = "onclick=dnir_delete('"+childKey+"')";

          //alert(chm);

        // console.log(childKey+": "+childSnapshot.val());

        //console.log(childData);

        var encdchky = encodeURIComponent('<?php echo $donor_listing;?>');
         

         var dnr_name = childData.name;
         var dnr_mobl = childData.mobile_no;
         var dnr_gndr = childData.gender;
         var dnr_age = childData.donor_age;
         var dnr_bldgrp = childData.bloodgroup;
         var dnr_addr = childData.address;
         
          cunt = cunt+1;

          
         
         $("#tabledtl").append("<tr id='tblrow"+childKey+"'><td>" + cunt + "</td><td>" + dnr_name + "</td><td>" + dnr_mobl + "</td><td>" + dnr_gndr + "</td><td>" + dnr_age + "</td><td>" + dnr_bldgrp + "</td><td>" + dnr_addr + "</td><td><a href= 'http://rayvil.com/firebase/edit_donor.php?dnr_st=<?php echo $donor_state; ?>&dnr_lst="+encdchky+"&u_Id="+childKey+"' class='btn btn-primary'>Edit</a><button "+ clickfun +" class='btn btn-danger'>Delete</button></td></tr>");


      





        //   var row = tableuser.insertRow(rowIndex);

        //   var cellId = row.insertCell(0);
        //   cellId.appendChild(document.createTextNode(childKey));
        
        //   rowIndex = rowIndex + 1;



     




        });
      
    
    });

  
    function dnir_delete(key){

      ///var chm = "'"+childKey+"'";  

      //alert(key);

    var uky = key;
   //alert(uky);

   var result = firebase.database().ref().child('Donor/<?php echo $donor_state.'/'.$donor_listing.'/';?>'+uky).remove();


   $('#tblrow'+key).remove();

  

  console.log(result);

  

     alert('Deleted');


    }

  


</script>
