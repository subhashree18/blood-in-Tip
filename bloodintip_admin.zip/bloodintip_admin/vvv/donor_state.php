<html>
   <head>
   <title>
    Blood In Tip
   </title>
   </head>
<body>
      <div class="container">
      <h2 class = "heading">Blood Group</h2>
     <table id="tabledtl" border="1" >
        
        <tr>

        <td><b>Blood Group</b></td>
        <td><b>View</b></td>

      </tr>
     
     </table>
   </div>

</body>


</html>







<script src="https://www.gstatic.com/firebasejs/4.8.2/firebase.js"></script>
<script>
  // Initialize Firebase
  var config = {
    apiKey: "AIzaSyDEIyc8Bhj9St2BZV0Zmi5nvzwbAs4aqno",
    authDomain: "bloodintip.firebaseapp.com",
    databaseURL: "https://bloodintip.firebaseio.com",
    projectId: "bloodintip",
    storageBucket: "",
    messagingSenderId: "16342465035"
  };
  firebase.initializeApp(config);
</script>
<script src="donor.js"></script>

<script src="https://code.jquery.com/jquery-1.12.4.js"></script>