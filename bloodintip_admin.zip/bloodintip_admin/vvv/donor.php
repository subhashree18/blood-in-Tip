<html>
   <head>
   <title>
    Blood In Tip
   </title>

   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/css/bootstrap.min.css">

   </head>
<body>
      <div class="container">
      <h2 class = "heading">Blood In Tip</h2>
     <table id="tabledtl" border="1" class="table" >
        
        <tr class="success">
        <td><b>Sl No.</b></td>
        <td><b>Donor State</b></td>
        <td><b>View</b></td>

      </tr>
     
     </table>
   </div>

</body>


</html>







<script src="https://www.gstatic.com/firebasejs/4.8.2/firebase.js"></script>
<script>
  // Initialize Firebase
  var config = {
    apiKey: "AIzaSyDEIyc8Bhj9St2BZV0Zmi5nvzwbAs4aqno",
    authDomain: "bloodintip.firebaseapp.com",
    databaseURL: "https://bloodintip.firebaseio.com",
    projectId: "bloodintip",
    storageBucket: "",
    messagingSenderId: "16342465035"
  };
  firebase.initializeApp(config);
</script>
<script src="donor.js"></script>

<script src="https://code.jquery.com/jquery-1.12.4.js"></script>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/js/bootstrap.min.js" ></script>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>


<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>