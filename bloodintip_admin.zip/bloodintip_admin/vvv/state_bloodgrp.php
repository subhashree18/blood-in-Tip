<html>
   <head>
   <title>
    Blood In Tip
   </title>

   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/css/bootstrap.min.css">

   </head>
<body>
      <div class="container">
      <h2 class = "heading">Blood Group</h2>
     <table id="tabledtl" border="1" class="table">
        
        <tr class="info">
        
        <td><b>Sl No.</b></td>
        <td><b>Blood Group</b></td>
        <td><b>View</b></td>

      </tr>
     
     </table>
   </div>

</body>


</html>







<script src="https://www.gstatic.com/firebasejs/4.8.2/firebase.js"></script>
<script>
  // Initialize Firebase
  var config = {
    apiKey: "AIzaSyDEIyc8Bhj9St2BZV0Zmi5nvzwbAs4aqno",
    authDomain: "bloodintip.firebaseapp.com",
    databaseURL: "https://bloodintip.firebaseio.com",
    projectId: "bloodintip",
    storageBucket: "",
    messagingSenderId: "16342465035"
  };
  firebase.initializeApp(config);   
</script>
<!-- <script src="state_bloodgrp.js"></script> -->

<script src="https://code.jquery.com/jquery-1.12.4.js"></script>


<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/js/bootstrap.min.js" ></script>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>


<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>


<?php 
$donor_state = $_GET['donor_state'];


?>

<script>

var tableuser = document.getElementById("tabledtl");
var databaseRef = firebase.database().ref('Donor/<?php echo $donor_state;?>/');

var count =0;
      databaseRef.once('value', function(snapshot) {

        //console.log(snapshot);

        snapshot.forEach(function(childSnapshot) {
          var childKey = childSnapshot.key;
         //var childData = childSnapshot.val();
  
        /// console.log(childData);
         
         ///console.log(childKey+": "+childSnapshot.val());

        ///console.log(childData);
        
        var encdchky = encodeURIComponent(childKey);

        //alert(encdchky);

         count = count+1;

    $("#tabledtl").append("<tr><td>" + count + "</td><td>" + childKey + "</td><td><a class= 'btn btn-primary' href='http://rayvil.com/firebase/donor_list.php?donor_state=<?php echo $donor_state;?>&donor_name="+encdchky+"'>View</a></td></tr>");

        //   var row = tableuser.insertRow(rowIndex);

        //   var cellId = row.insertCell(0);
        //   cellId.appendChild(document.createTextNode(childKey));
        
        //   rowIndex = rowIndex + 1;








        });
      
    
    });


</script>