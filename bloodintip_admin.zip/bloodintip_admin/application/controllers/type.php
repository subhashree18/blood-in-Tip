<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Type extends CI_Controller {
    
 /**
* Name:  Type Module
*
* 
* Author: Milan Krushna
*		  Milan.wayindia@gmail.com
*         
* Created : 20.06.2016
    
 */   
    

  

function __construct()
  {
    parent::__construct();
   
    $this->load->library(array('form_validation','session','pagination','ion_auth'));
    $this->load->model('admin/type_model');
    $this->load->helper(array('form', 'url'));
    date_default_timezone_set("Asia/Kolkata");
    
    
    $this->header['heading']="Emergency Type";  
    $this->header['menu']=1;  
    
    if (!$this->ion_auth->logged_in())
    {
      redirect('admin/auth', 'refresh');
    }
   $this->header['webdata'] = $this->db->get_where('my_website',array('id'=>'1'))->row();
    
    
    
    
  }

public function index($id=NULL)
  {
    $this->header['subHeading']="Type Listing"; 
    $this->data['types'] = $this->type_model->get_type();
          
    $this->load->view('common_admin/header',$this->header);
    $this->load->view('admin/type/listing',$this->data);
    $this->load->view('common_admin/footer',$this->header);
    
  }
    
    public function CreateType($id=NULL)
  {
    
$this->header['subHeading']="New Type";
        
$this->form_validation->set_rules('name', 'Type Name', 'required|is_unique[type.name]');   
 
     if ($this->form_validation->run() == FALSE)
     {
        
         if($this->input->post('name') !=""){
             $this->data['name'] = $this->input->post('name');
         }else{
            $this->data['name'] = ""; 
         }
         if($this->input->post('desc') !=""){
             $this->data['desc'] = $this->input->post('desc');
         }else{
            $this->data['desc'] = ""; 
         }
         
       
    $this->load->view('common_admin/header',$this->header);
    $this->load->view('admin/type/new_type',$this->data);
    $this->load->view('common_admin/footer',$this->header);
     
     }else{
      
         $type['name'] = $this->input->post('name');
         $type['desc'] = $this->input->post('desc');
         
      
         
         if($this->type_model->CreateNewType($type)){
             
            $this->session->set_flashdata('message','Type Successfully Created');
             redirect('type/CreateType');
         }
         
         
     }
  }

    function editType($id=null){
        $this->header['subHeading']="Modify Type";
        if($id==""){
        show_404();
        }
        
        $row['id'] = $id;
        $this->data['type'] = $this->type_model->get_type_row($row);
      
        
    $this->form_validation->set_rules('name', 'Type Name', 'required');   
 
     if ($this->form_validation->run() == FALSE)
     {
    
       
    $this->load->view('common_admin/header',$this->header);
    $this->load->view('admin/type/modify_type',$this->data);
    $this->load->view('common_admin/footer',$this->header);
     
     }else{
      
         $type['name'] = $this->input->post('name');
         $type['desc'] = $this->input->post('desc');
         
      
         
         if($this->type_model->update_type($type,$row)){
             
            $this->session->set_flashdata('message','Type Successfully Updated');
            redirect('type/editType/'.$id);
         }
         
         
     }
        
    }
    
    function RemoveType($id=null){
        if($id==""){
        show_404();
        }
        
        $row['id'] = $id;
        if($this->type_model->Delete_type($row)){
             
            $this->session->set_flashdata('message','Type Successfully Deleted');
             redirect('type/');
         }
        
        
        
    }
    




}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */
