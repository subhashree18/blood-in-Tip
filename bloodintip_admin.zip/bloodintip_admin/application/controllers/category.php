<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Category extends CI_Controller {
    
 /**
* Name:  Category Module
*
* 
* Author: Milan Krushna
*		  Milan.wayindia@gmail.com
*         
* Created : 20.06.2016
    
 */   
    
  

function __construct()
  {
    parent::__construct();
   
    $this->load->library(array('form_validation','session','pagination','ion_auth'));
    $this->load->model('admin/ctgy_model');
    $this->load->helper(array('form', 'url'));
    date_default_timezone_set("Asia/Kolkata");
    
    
    $this->header['heading']="Emergency Category";  
    $this->header['menu']=2;  
    
    if (!$this->ion_auth->logged_in())
    {
      redirect('admin/auth', 'refresh');
    }
   $this->header['webdata'] = $this->db->get_where('my_website',array('id'=>'1'))->row();
    
    
    
    
  }

public function index($id=NULL)
  {
    $this->header['subHeading']="Category Listing"; 
    $this->data['category'] = $this->ctgy_model->get_category();
          
    $this->load->view('common_admin/header',$this->header);
    $this->load->view('admin/category/listing',$this->data);
    $this->load->view('common_admin/footer',$this->header);
    
  }
    
    public function CreateCategory($id=NULL)
  {
    
$this->header['subHeading']="New Type";
$this->data['types'] = $this->ctgy_model->get_types();
        
$this->form_validation->set_rules('name', 'Category Name', 'required|is_unique[type.name]');   
$this->form_validation->set_rules('type_id', 'Type Name', 'required');   
$this->form_validation->set_rules('city', 'City Name', 'required');   
$this->form_validation->set_rules('address', 'address', 'required');   
$this->form_validation->set_rules('phone', 'Phone Number', 'required');   
 
     if ($this->form_validation->run() == FALSE)
     {
        
         if($this->input->post('name') !=""){
             $this->data['name'] = $this->input->post('name');
         }else{
            $this->data['name'] = ""; 
         }
         if($this->input->post('type_id') !=""){
             $this->data['t_id'] = $this->input->post('type_id');
         }else{
            $this->data['t_id'] = ""; 
         }
         if($this->input->post('city') !=""){
             $this->data['city'] = $this->input->post('city');
         }else{
            $this->data['city'] = ""; 
         }
         if($this->input->post('address') !=""){
             $this->data['address'] = $this->input->post('address');
         }else{
            $this->data['address'] = ""; 
         }
         if($this->input->post('phone') !=""){
             $this->data['phone'] = $this->input->post('phone');
         }else{
            $this->data['phone'] = ""; 
         }
         
       
    $this->load->view('common_admin/header',$this->header);
    $this->load->view('admin/category/new_category',$this->data);
    $this->load->view('common_admin/footer',$this->header);
     
     }else{
      
         $ctgy['name'] = $this->input->post('name');
         $ctgy['type_id'] = $this->input->post('type_id');
         $ctgy['city'] = $this->input->post('city');
         $ctgy['address'] = $this->input->post('address');
         $ctgy['phone'] = serialize(explode(',',$this->input->post('phone')));
         
      
         
         if($this->ctgy_model->CreateNewctgy($ctgy)){
             
            $this->session->set_flashdata('message','Category Successfully Created');
             redirect('category/CreateCategory');
         }
         
         
     }
  }

    function editCategory($id=null){
        $this->header['subHeading']="Modify Type";
        if($id==""){
        show_404();
        }
        
        $row['id'] = $id;
        $this->data['types'] = $this->ctgy_model->get_types();
        $this->data['ctgy'] = $this->ctgy_model->get_ctgy_row($row);
      
        
$this->form_validation->set_rules('name', 'Category Name', 'required|is_unique[type.name]');   
$this->form_validation->set_rules('type_id', 'Type Name', 'required');   
$this->form_validation->set_rules('city', 'City Name', 'required');   
$this->form_validation->set_rules('address', 'address', 'required');   
$this->form_validation->set_rules('phone', 'Phone Number', 'required');   
 
     if ($this->form_validation->run() == FALSE)
     {
    
       
    $this->load->view('common_admin/header',$this->header);
    $this->load->view('admin/category/modify_category',$this->data);
    $this->load->view('common_admin/footer',$this->header);
     
     }else{
      
         $ctgy['name'] = $this->input->post('name');
         $ctgy['type_id'] = $this->input->post('type_id');
         $ctgy['city'] = $this->input->post('city');
         $ctgy['address'] = $this->input->post('address');
         $ctgy['phone'] = serialize(explode(',',$this->input->post('phone')));
         
      
         
         if($this->ctgy_model->update_category($ctgy,$row)){
             
            $this->session->set_flashdata('message','Category Successfully Updated');
            redirect('category/editCategory/'.$id);
         }
         
         
     }
        
    }
    
    function RemoveCategory($id=null){
        if($id==""){
        show_404();
        }
        
        $row['id'] = $id;
        if($this->ctgy_model->Delete_category($row)){
             
            $this->session->set_flashdata('message','Category Successfully Deleted');
             redirect('category/');
         }
        
        
        
    }
    




}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */
