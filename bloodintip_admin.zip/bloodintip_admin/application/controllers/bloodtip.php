<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Bloodtip extends CI_Controller {
    
 /**
* Name:  Type Module
*
* 
* Author: Milan Krushna
*		  Milan.wayindia@gmail.com
*         
* Created : 20.06.2016
    
 */   
    

  

function __construct()
  {
    parent::__construct();
   
     $this->load->library('ion_auth');
    $this->load->library(array('form_validation','session'));
   // $this->load->model('admin/type_model');
    $this->load->helper(array('form', 'url'));
    date_default_timezone_set("Asia/Kolkata");
    
    
        $this->load->database();
		$this->lang->load('auth');
        $this->load->helper('language');
        $this->load->library('session');
        $this->header['heading']="Blood In Tip";  
        $this->header['menu']=1;  
    
    if (!$this->ion_auth->logged_in())
    {
      redirect('admin/auth', 'refresh');
    }
   $this->header['webdata'] = $this->db->get_where('my_website',array('id'=>'1'))->row();
    
    
    
    
  }  

public function index($id=NULL)
  {
   
          
    $this->load->view('common_admin/header',$this->header);
    $this->load->view('mainbody/donor');
    $this->load->view('common_admin/footer',$this->header);
    
  }
    
 function state_bloodgrp(){
    
     $donor_state = $_GET['donor_state'];
     $this->data['donor_state'] = $donor_state;
     
   $this->load->view('common_admin/header',$this->header);
    $this->load->view('mainbody/state_bloodgrp',$this->data);
    $this->load->view('common_admin/footer',$this->header);  
     
     
 }  

    function donor_list(){
        
        $donor_state = $_GET['donor_state'];
$donor_listing = $_GET['donor_name'];
       
         $this->data['donor_state'] = $donor_state;
         $this->data['donor_listing'] = $donor_listing;
        
        
        $this->load->view('common_admin/header',$this->header);
    $this->load->view('mainbody/donor_list',$this->data);
    $this->load->view('common_admin/footer',$this->header); 
        
    }
    
    
    function edit_donor(){
       
        
$donor_state = $_GET['dnr_st'];
$donor_listing = $_GET['dnr_lst'];

$ID = $_GET['u_Id'];

     $this->data['donor_state'] = $donor_state;  
     $this->data['donor_listing'] = $donor_listing;  
     $this->data['ID'] = $ID;  
        
       
     $this->load->view('common_admin/header',$this->header);
    $this->load->view('mainbody/edit_donor',$this->data);
    $this->load->view('common_admin/footer',$this->header);   
        
        
    }
    
   function add_event(){
       
     $this->load->view('common_admin/header',$this->header);
    $this->load->view('mainbody/create_event');
    $this->load->view('common_admin/footer',$this->header);      
       
   }
    
    function all_event(){
        
     $this->load->view('common_admin/header',$this->header);
    $this->load->view('mainbody/view_event');
    $this->load->view('common_admin/footer',$this->header);      
        
        
    }
    
    function edit_event(){
        
      $ID = $_GET['u_Id'];

      
     $this->data['ID'] = $ID;  
        
       
     $this->load->view('common_admin/header',$this->header);
    $this->load->view('mainbody/edit_event',$this->data);
    $this->load->view('common_admin/footer',$this->header);     
        
    }
    
    
    function Image_upload(){
        
      $this->load->view('common_admin/header',$this->header);
    $this->load->view('mainbody/file_upload');
    $this->load->view('common_admin/footer',$this->header);   
        
    }

}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */
