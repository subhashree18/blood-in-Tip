<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Ctgy_model extends CI_Model {

    
/**
* Name:  Type Module
*
* 
* Author: Milan Krushna
*		  Milan.wayindia@gmail.com
*         
* Created : 20.06.2016
    
**/   
    
    
  public function __construct()

	{

		parent::__construct();

		$this->load->database();
        $this->load->library('session');

	}
  
  
    function get_types(){
            
       return $this->db->get('type')->result();
        
    }
    function get_category(){
            
       return $this->db->select('category.*,type.name as type')
                       ->join('type','type.id = category.type_id')
                       ->get('category')->result();
        
    }
    
    function CreateNewctgy($data){
        return $this->db->insert('category',$data);
    }
    
    function get_ctgy_row($column){
   
       return $this->db->get_where('category',$column)->row();
        
    }
    
    function update_category($data,$column){
            
       return $this->db->Update('category',$data,$column);
        
    }
    function Delete_category($column){
        
       return $this->db->delete('category',$column);
        
    }
    
    
    
    
    
    
    
		
}