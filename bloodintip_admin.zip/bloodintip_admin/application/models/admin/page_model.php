<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');





class page_model extends CI_Model

{

	/**

	 * Holds an array of tables used

	 *

	 * @var array

	 **/

	public $tables = array();



	/**

	 * activation code

	 *

	 * @var string

	 **/

	public $activation_code;



	/**

	 * forgotten password key

	 *

	 * @var string

	 **/

	public $forgotten_password_code;



	/**

	 * new password

	 *

	 * @var string

	 **/

	public $new_password;



	/**

	 * Identity

	 *

	 * @var string

	 **/

	public $identity;



	/**

	 * Where

	 *

	 * @var array

	 **/

	public $_ion_where = array();



	/**

	 * Select

	 *

	 * @var array

	 **/

	public $_ion_select = array();



	/**

	 * Like

	 *

	 * @var array

	 **/

	public $_ion_like = array();



	/**

	 * Limit

	 *

	 * @var string

	 **/

	public $_ion_limit = NULL;



	/**

	 * Offset

	 *

	 * @var string

	 **/

	public $_ion_offset = NULL;



	/**

	 * Order By

	 *

	 * @var string

	 **/

	public $_ion_order_by = NULL;



	/**

	 * Order

	 *

	 * @var string

	 **/

	public $_ion_order = NULL;



	/**

	 * Hooks

	 *

	 * @var object

	 **/

	protected $_ion_hooks;



	/**

	 * Response

	 *

	 * @var string

	 **/

	protected $response = NULL;



	/**

	 * message (uses lang file)

	 *

	 * @var string

	 **/

	protected $messages;



	/**

	 * error message (uses lang file)

	 *

	 * @var string

	 **/

	protected $errors;



	/**

	 * error start delimiter

	 *

	 * @var string

	 **/

	protected $error_start_delimiter;



	/**

	 * error end delimiter

	 *

	 * @var string

	 **/

	protected $error_end_delimiter;



	/**

	 * caching of users and their groups

	 *

	 * @var array

	 **/

	public $_cache_user_in_group = array();



	/**

	 * caching of groups

	 *

	 * @var array

	 **/

	protected $_cache_groups = array();



	public function __construct()

	{

		parent::__construct();

		$this->load->database();

		$this->load->config('ion_auth', TRUE);

		//$this->load->helper('cookie');

		//$this->load->helper('date');

		$this->lang->load('ion_auth');
		 $this->load->library('session');


	

	}

	

	


	
	public function create_page($data)
	{
            
			$insert = $this->db->insert('pages',$data);
                        return $insert;
			
	}





	function create_pdf($data,$page_id){

$insert = $this->db->update('pages',$data,array('id'=>$page_id));
                     

	}
	
	function create_hotspot($data,$mapid){

			if($mapid == "undefined"){
	$insert = $this->db->insert('hotspot',$data);
	                        return $insert;
	                    }else{
$this->db->update('hotspot', $data, array('id' => $mapid));
		
	                    
	                    }
	}

	
	function  get_pages($id){
		$this->db->select('pages.*,edition.name as ed_name');
		$this->db->from('pages');
                $this->db->join('edition','pages.edition_id = edition.id');
                $this->db->where('pages.edition_id =', $id);
                 $this->db->order_by("short_id","ASC");
		$query = $this->db->get();
                //print("<pre>");
                //print_r( $query->result_array());
                //exit;
                return $query->result_array();	
	 }
         
         function get_result($data){
                 $this->db->select('pages.* ,edition.name as ed_name');
				$this->db->from('pages');
                 $this->db->join('edition','pages.edition_id = edition.id');
                $this->db->where('pages.edition_id',$data['edition_id']);
                $this->db->where('pages.date',$data['date']);
                 $this->db->order_by("short_id","ASC");
		$query = $this->db->get();
		return $query->result_array();
         }
         
      public function update_page2($data, $cond){
	 
             
	 	$res = $this->db->update('pages', $data, array('edition_id' => $cond['edition_id'],'date' => $cond['date']));
		return $res;

	 }



         function  get_page2($id){
		$this->db->select('*');
		//$this->db->join('edition','edition.id = pages.id');
                $this->db->from('pages');
		$this->db->where('id',$id);
		$query = $this->db->get();
		return $query->row_array();	
	 }

	 

	 public function update_page($data, $id){
	 
             
	 	$res = $this->db->update('pages', $data, array('id' => $id));
		return $res;

	 }
	

	public function delete_page($id){
			
            $delete  = $this->db->delete('pages', array('id' => $id)); 
			return $delete;
	}
	public function delete_pdf($id){
			
            $delete  = $this->db->delete('pdf', array('id' => $id)); 
			return $delete;
	}
	
	public function delete_by_date($id){
			
            $delete  = $this->db->delete('pages', array('date' => $id)); 
			return $delete;
	}
	



	
	// end of the supervisor
	
	function  getgroup(){
		$this->db->select('*');
		$this->db->from('groups');		 
		$query = $this->db->get();
		return $query->result_array();	
	 }


	function  getmenu(){
		$this->db->select('*');
		$this->db->from('menu');
		$query = $this->db->get();
		return $query->result_array();	
	 }
	

function get_page_cord($id){

		
		$this->db->select('*');
		$this->db->from('hotspot');
		$this->db->where('page_id',$id);
		$query = $this->db->get();
		return $query->result_array();	

}

function get_cord($id){

		$this->db->select('*');
		$this->db->from('hotspot');
		$this->db->where('id',$id);
		$query = $this->db->get();
		return $query->row_array();	

}

function get_status($data){
		$this->db->select('*');
		$this->db->from('pages');
		$this->db->where('edition_id',$data['edition_id']);
		$this->db->where('date',$data['date']);
		$query = $this->db->get();
		return $query->row_array();	

} 
function get_img($id){

$this->db->select('*');
		$this->db->from('pages');
		$this->db->where('id',$id);
		$query = $this->db->get();
		return $query->row_array();	

}

function remove_hotspot($id){
     $delete  = $this->db->delete('hotspot', array('id' => $id)); 
			return $delete;


}

/*  -----------------Sbuscription Start Here--------------------    */



function create_subscription($data){

$insert = $this->db->insert('subscription',$data);
                        return $insert;


}


function get_subscription(){

	return $this->db->get('subscription')->result_array();
}


function get_sub($id){

	return $this->db->get_where('subscription',array('id'=>$id))->row_array();
}

function update_sub($data,$id){

	return $this->db->update('subscription',$data,array('id' => $id));
}



function get_ed_pages($id){



}








	
}