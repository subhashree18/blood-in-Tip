<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Type_model extends CI_Model {

    
/**
* Name:  Type Module
*
* 
* Author: Milan Krushna
*		  Milan.wayindia@gmail.com
*         
* Created : 20.06.2016
    
**/   
    
    
  public function __construct()

	{

		parent::__construct();

		$this->load->database();
        $this->load->library('session');

	}
  
  
    function get_type(){
            
       return $this->db->get('type')->result();
        
    }
    
    function get_type_row($column){
   
       return $this->db->get_where('type',$column)->row();
        
    }
    
    function update_type($data,$column){
            
       return $this->db->Update('type',$data,$column);
        
    }
    function Delete_type($column){
        
       return $this->db->delete('type',$column);
        
    }
    
    
    
    
    
    
    
		
}