   		
  <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1><?php echo $heading; ?></h1>
         
        </section>

        <!-- Main content -->
        <section class="content">
        <?php if($this->session->flashdata('message')){?>
             
					<div class="alert alert-info alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <h4>	<i class="icon fa fa-check"></i> Message!</h4>
                    <?php echo $this->session->flashdata('message');?>
                  </div>


          <?php } ?>
          <!-- Default box -->
    
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title"><?php echo $subHeading; ?></h3>
            
                <a class="btn btn-success btn-flat pull-right" href="<?php echo site_url('category/CreateCategory')?>" ><i class="fa fa-plus"></i></a>
            </div>
              
              
              
          <table class="table table-bordered table-hover table-striped ">
	<tr>
		<th>Name</th>
		<th>Type</th>
		<th>City</th>
		<th>Address</th>
		<th>Phone</th>
        <th>Action</th>
		
	</tr>
	<?php foreach ($category as $typ){?>
		<tr>
            <td><?php echo $typ->name; ?></td>
            <td><?php echo $typ->type; ?></td>
            <td><?php echo $typ->city; ?></td>
            <td><?php echo $typ->address; ?></td>
            <td><?php $phone= unserialize($typ->phone); foreach($phone as $key => $value){ 
            echo $value.',';
            } ?>
            </td>
            
            
            <td><a href="<?php echo site_url('category/editCategory/'.$typ->id)?>"  title="Edit" class="btn btn-warning btn-flat btn-sm"><i class="fa fa-pencil-square-o"></i></a><a onclick="return confirm('Are You Sure Delete this type')" href="<?php echo site_url('category/RemoveCategory/'.$typ->id); ?>" title="Delete" class="btn btn-danger btn-flat btn-sm"><i class="fa fa-trash"></i></a></td>
			<?php } ?>
</table>
            
          </div><!-- /.box -->

        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
