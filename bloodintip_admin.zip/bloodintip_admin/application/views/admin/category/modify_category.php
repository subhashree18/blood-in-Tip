   		
  <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1><?php echo $heading; ?></h1>
         
        </section>
          
          
          
        <!-- Main content -->
        <section class="content">
            <div class="row">
            <div class="col-md-6">
        <?php if($this->session->flashdata('message')){?>
              
					<div class="alert alert-info alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <h4>	<i class="icon fa fa-check"></i> Message!</h4>
                    <?php echo $this->session->flashdata('message');?>
                  </div>


          <?php } ?>
          <!-- Default box -->
    
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title"><?php echo $subHeading; ?></h3>
            
                <a class="btn bg-purple btn-flat pull-right" href="<?php echo site_url('category')?>" ><i class="fa fa-mail-reply"></i></a>
            </div>
          
             <form role="form" action="<?php echo current_url(); ?>" method="post">
              <div class="box-body">
                <div class="form-group">
                  <label for="exampleInputEmail1">Choose Type <span class="text-red">*</span></label>
                  <select class="form-control" name="type_id" required>
                      <option value=""> Choose Type </option>
                      <?php foreach($types as $typ){ ?>
                      <option <?php  if($ctgy->type_id == $typ->id){ ?> selected = "selected" <?php } ?> value="<?php echo $typ->id;  ?>"> <?php echo $typ->name;  ?> </option>
                      <?php } ?>
                  </select>
                  <?php echo form_error('type_id'); ?>
                </div>
                  <div class="form-group">
                  <label for="exampleInputEmail1">Category<span class="text-red">*</span></label>
                  <input type="text" name="name" class="form-control" value="<?php echo $ctgy->name; ?>"   placeholder="Category Name" required>
                  <?php echo form_error('name'); ?>
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">City<span class="text-red">*</span></label>
                  <input type="text" name="city" class="form-control" value="<?php echo $ctgy->city; ?>"  placeholder="Description" required>
                <?php echo form_error('city'); ?>
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Address<span class="text-red">*</span></label>
                  <input type="text" name="address" class="form-control" value="<?php echo $ctgy->address; ?>"  placeholder="Description" required>
                <?php echo form_error('address'); ?>
                </div>
                 <div class="form-group">
                  <label for="exampleInputPassword1">phone<span class="text-red">*</span></label>
                     <p class="help-block">Seperated By Comma(,)</p>
                  <input type="text" name="phone" class="form-control" value="<?php $phone= unserialize($ctgy->phone); foreach($phone as $key => $value){ 
            echo $value.',';
            } ?>"  placeholder="Description" required>
                <?php echo form_error('phone'); ?>
                </div>
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>
            </form> 
              
              
              
              
              
              
              
              
            
          </div><!-- /.box -->
          </div><!-- /.box -->
          </div><!-- /.box -->

        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
      <!-- /.content-wrapper -->
