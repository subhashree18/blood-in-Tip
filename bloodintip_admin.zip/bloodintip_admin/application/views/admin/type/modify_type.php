   		
  <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1><?php echo $heading; ?></h1>
         
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">
            <div class="col-md-6">
        <?php if($this->session->flashdata('message')){?>
              
					<div class="alert alert-info alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <h4>	<i class="icon fa fa-check"></i> Message!</h4>
                    <?php echo $this->session->flashdata('message');?>
                  </div>


          <?php } ?>
          <!-- Default box -->
    
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title"><?php echo $subHeading; ?></h3>
            
                <a class="btn bg-purple btn-flat pull-right" href="<?php echo site_url('type')?>" ><i class="fa fa-mail-reply"></i></a>
            </div>
          
             <form role="form" action="<?php echo current_url(); ?>" method="post">
              <div class="box-body">
                <div class="form-group">
                    <label for="exampleInputEmail1">Type<span class="text-red">*</span></label>
                  <input type="text" name="name" class="form-control" value="<?php echo $type->name; ?>"   placeholder="Type Name" required>
                  <?php echo form_error('name'); ?>
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Description</label>
                  <input type="text" name="desc" class="form-control" value="<?php echo $type->desc; ?>"  placeholder="Description">
                <?php echo form_error('desc'); ?>
                  </div>
                
                
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Update</button>
              </div>
            </form> 
              
              
              
              
              
              
              
              
            
          </div><!-- /.box -->
          </div><!-- /.box -->
          </div><!-- /.box -->

        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
