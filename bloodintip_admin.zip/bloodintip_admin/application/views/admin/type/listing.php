   		
  <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1><?php echo $heading; ?></h1>
         
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">
            <div class="col-md-6">
        <?php if($this->session->flashdata('message')){?>
              
					<div class="alert alert-info alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <h4>	<i class="icon fa fa-check"></i> Message!</h4>
                    <?php echo $this->session->flashdata('message');?>
                  </div>


          <?php } ?>
          <!-- Default box -->
    
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title"><?php echo $subHeading; ?></h3>
            
                <a class="btn btn-success btn-flat pull-right" href="<?php echo site_url('type/CreateType')?>" ><i class="fa fa-plus"></i></a>
            </div>
          <table class="table table-bordered table-hover table-striped ">
	<tr>
		<th>Name</th>
	
		<th>Action</th>
		
	</tr>
	<?php foreach ($types as $typ){a?>
		<tr>
            <td><?php echo $typ->name; ?></td>
            
            
            <td><a href="<?php echo site_url('type/editType/'.$typ->id)?>"  title="Edit" class="btn btn-warning btn-flat btn-sm"><i class="fa fa-pencil-square-o"></i></a><a onclick="return confirm('Are You Sure Delete this type')" href="<?php echo site_url('type/RemoveType/'.$typ->id); ?>" title="Delete" class="btn btn-danger btn-flat btn-sm"><i class="fa fa-trash"></i></a></td>
			<?php } ?>
</table>
            
          </div><!-- /.box -->
          </div><!-- /.box -->
          </div><!-- /.box -->

        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
