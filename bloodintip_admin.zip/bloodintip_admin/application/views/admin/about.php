


    <!-- END PAGE LEVEL  STYLES -->
     <!--PAGE CONTENT --> 
    <div class="content-wrapper">
              <section class="content-header">
                  <center><h1>WELCOME</h1></center>
         
        </section>
        <section class="content">
<div class="box box-primary">
<div class="box-body" >
    <div class="col-md-3"></div>
    
    <div class="col-md-6">
              <!-- USERS LIST -->
              <div class="box box-danger">
                <div class="box-header with-border">
                    <center><h3 class="box-title">Website Detail</h3></center>

                 
                </div>
                <!-- /.box-header -->
                <div class="box-body no-padding">
                 
                      
                      
                      <form class="form-horizontal" action="<?php echo site_url('admin/dashboard/index')?>" method="post">
              <div class="box-body">
                  <?php echo validation_errors(); ?>
                <div class="form-group">
                    <center><img src="<?php echo base_url() ?>assets/user/images/<?php echo $website_data->logo ?>" style="
    width: 300px;" alt="User Image"></center><br>
                  <label for="inputEmail3" class="control-label">Website Logo</label>
    
                  <div class="">
                    <input type="file" name="wlogo" class="form-control"  id="inputEmail3" placeholder="Website Title" >
                  </div>
                </div>
                  <div class="form-group">
                  <label for="inputEmail3" class="control-label">Website Title</label>

                  <div class="">
                    <input type="text" name="title" value="<?php echo $website_data->title ?>" class="form-control" id="inputEmail3" placeholder="Website Title" required>
                  </div>
                </div>
                  <div class="form-group">
                  <label for="inputEmail3" class="control-label">Website Name</label>

                  <div class="">
                    <input type="text" name="name" value="<?php echo $website_data->name ?>" class="form-control" id="inputEmail3" placeholder="Website Name" required>
                  </div>
                </div>
                  <div class="form-group">
                  <label for="inputEmail3" class="control-label">Admin panel Title</label>

                  <div class="">
                    <input type="text" name="admin_panel_name" value="<?php echo $website_data->admin_panel_name ?>" class="form-control" id="inputEmail3" placeholder="Website Name" required>
                  </div>
                </div>
                  <div class="form-group">
                  <label for="inputEmail3" class="control-label">Description</label>

                  <div class="">
                    <input type="text" name="description" value="<?php echo $website_data->description ?>" class="form-control" id="inputEmail3" placeholder="Website Name" required>
                  </div>
                </div>
              </div>
              <!-- /.box-body -->
              <div class="box-footer">

                <button onclick="return confirm('Are You Sure')" type="submit" class="btn btn-info pull-right">Update</button>
              </div>
              <!-- /.box-footer -->
            </form>

                 
                </div>
              
              </div>
              <!--/.box -->
            </div>
<div class="col-md-3"></div>

    
</div>
</div>
 </section>
    </div>
          