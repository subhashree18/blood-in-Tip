

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Emergency Service | Admin Panlel</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="<?php echo base_url()?>assets/bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo base_url()?>assets/dist/fonts_asm/font-awesome.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="<?php echo base_url()?>assets/dist/fonts_asm/ionicons.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo base_url()?>assets/dist/css/AdminLTE.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="<?php echo base_url()?>assets/plugins/iCheck/square/blue.css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body class="hold-transition login-page">
    <div class="login-box">
      <div class="login-logo">
          <center><img src="<?php echo base_url() ?>assets/user/images/logo.png" class="img-responsive" title="logo" alt="logo"></center>

         
      </div><!-- /.login-logo -->
      <div class="login-box-body">
        <?php if ($message){?>    
        <div class="alert alert-info">
          
         <div style="text-align: center;"> <?php echo $message; ?></div>
        </div>
        <?php }?>
        <p class="login-box-msg"><?php echo lang('reset_password_sub_heading'); ?></p>
        <form action="<?php echo site_url("admin/auth/reset_password/".$code)?>" method="post">
          <div class="form-group has-feedback">
              <input type="password" name="new" placeholder="Password" class="form-control" value="" id="new" pattern="^.{8}.*$"  />
              
            <span class="glyphicon glyphicon-lock form-control-feedback"></span>
          </div>
          <div class="form-group has-feedback">
              <input type="password" placeholder="Confirm Password" name="new_confirm" class="form-control" value="" id="new_confirm" pattern="^.{8}.*$"  />
            <span class="glyphicon glyphicon-lock form-control-feedback"></span>
          </div>
       <?php echo form_input($user_id);?>
	<?php echo form_hidden($csrf); ?>
          <div class="row">
          
            <div class="col-xs-4">
              <button type="submit" class="btn btn-primary btn-block btn-flat">Reset</button>
            </div><!-- /.col -->
          </div>
        </form>

       
        <a href="<?php echo site_url('admin/auth/login')?>">Login</a><br>
        
      </div><!-- /.login-box-body -->
    </div><!-- /.login-box -->

    <!-- jQuery 2.1.4 -->
    <script src="<?php echo base_url()?>assets/plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- Bootstrap 3.3.5 -->
    <script src="<?php echo base_url()?>assets/bootstrap/js/bootstrap.min.js"></script>
   
   
  </body>
</html>


