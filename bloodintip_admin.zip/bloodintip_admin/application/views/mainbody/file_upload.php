   	<html>	
  <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>Create Events</h1>
         
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">
            <div class="col-md-6">
        <?php if($this->session->flashdata('message')){?>
              
					<div class="alert alert-info alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <h4>	<i class="icon fa fa-check"></i> Message!</h4>
                    <?php echo $this->session->flashdata('message');?>
                  </div>


          <?php } ?>
          <!-- Default box -->
    
          <div class="box">
            <div class="box-header with-border">
<!--              <h3 class="box-title">Create Events</h3>-->
            
<!--                <a class="btn bg-purple btn-flat pull-right" href="<?php echo site_url('type')?>" ><i class="fa fa-mail-reply"></i></a>-->
            </div>
          
              <form  id="registr">
                  
              <div class="box-body">
<!--
                <div class="form-group">
                    <label for="exampleInputEmail1">Image Heading<span class="text-red">*</span></label>
                   <input type="text" name="img_head" id="img_head" class="form-control" placeholder="Enter  heading">
                </div> 
                  
-->
                  
                  <div class="form-group">
                    <label for="exampleInputEmail1">Image Upload<span class="text-red">*</span></label>
                   <input type="file" name="file_upload" id="file_upload" class="form-control" placeholder="Enter  heading">
                </div>
                  
                  
                
              </div>
              <!-- /.box-body -->

              
             </form>
    
<!--
     <div class="box-footer">
            <button id="submit_evnt" type="button" class="btn btn-primary" onclick= "uploadimage();"  >Upload</button> 
              </div>
-->
              
              
              
              
              
            
          </div><!-- /.box -->
          </div><!-- /.box -->
          </div><!-- /.box -->

        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->


    
<script src="https://www.gstatic.com/firebasejs/4.10.0/firebase.js"></script>
<script>
  // Initialize Firebase
  var config = {
    apiKey: "AIzaSyDEIyc8Bhj9St2BZV0Zmi5nvzwbAs4aqno",
    authDomain: "bloodintip.firebaseapp.com",
    databaseURL: "https://bloodintip.firebaseio.com",
    projectId: "bloodintip",
    storageBucket: "bloodintip.appspot.com",
    messagingSenderId: "16342465035"
  };
  firebase.initializeApp(config);
</script>
    
</html>

<script>

 
  var database = firebase.database().ref();
   var storage = firebase.storage();
    
  
  var img_upload = document.getElementById("file_upload").value;
     
  //var imageurl = database.ref("Imageurl");
 function urlset(snap){
     
     var urlimg =  snap.downloadURL;
     
     console.log(urlimg);
     
      //imageurl.push("Imageurl" +urlimg );
 }
 
    
 function image_upload(){
   
    // alert("njxvjkxdnh");
     var filedata = this.files[0];
     
     //file storage
      var stordata = storage.ref("Images/" + new Date());
     stordata.put(filedata).then(urlset);
     
 }
 
  file_upload.onchange = image_upload;
 
 
 




</script>