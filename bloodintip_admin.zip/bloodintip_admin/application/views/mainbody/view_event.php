   		
  <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>All Events</h1>
         
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">
            <div class="col-md-12">
        <?php if($this->session->flashdata('message')){?>
              
					<div class="alert alert-info alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <h4>	<i class="icon fa fa-check"></i> Message!</h4>
                    <?php echo $this->session->flashdata('message');?>
                  </div>

                        
          <?php } ?>
          <!-- Default box -->
    
          <div class="box">
            <div class="box-header with-border">
             
            
<!--                <a class="btn btn-success btn-flat pull-right" href="<?php echo site_url('type/CreateType')?>" ><i class="fa fa-plus"></i></a>-->
            </div>
          <table id="tabledtl" class="table table-bordered table-hover table-striped ">
	<tr>
		<th>Sl No.</th>
	
		<th>Events</th>
		<th>Event Url</th>
		<th>Image</th>
		<th>Action</th>
		
	</tr>
	
</table>
            
          </div><!-- /.box -->
          </div><!-- /.box -->
          </div><!-- /.box -->

        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->

<script src="https://www.gstatic.com/firebasejs/4.10.0/firebase.js"></script>
<script>
  // Initialize Firebase
  var config = {
    apiKey: "AIzaSyB3GQCyKLo-PSJpscu1eB9sYG6hwYIo4-I",
    authDomain: "bloodinatip.firebaseapp.com",
    databaseURL: "https://bloodinatip.firebaseio.com",
    projectId: "bloodinatip",
    storageBucket: "bloodinatip.appspot.com",
    messagingSenderId: "808502238432"
  };
  firebase.initializeApp(config);
</script>
  
 <script>
   var site_url = "http://bloodinatip.com/bloodintip_admin/index.php"; 
  var tableuser = document.getElementById("tabledtl");
var databaseRef = firebase.database().ref('NewsEvents/');

var rowIndex = 1;
 
//console.log(databaseRef);

// databaseRef.on("child_added" ,snap => {

//     var donr = snap.val();
     
//       var Donor = snap.child().val();
     
//       console.log(donr);
     

//      donr.forEach(myFunction);

//       function myFunction(value , key){

//         $("#tabledtl").append("<tr><td>" + key + "</td><td><a >view</a></td></tr>");

//       }



var st = 0;

      databaseRef.once('value', function(snapshot) {

       

        snapshot.forEach(function(childSnapshot) {
          var childKey = childSnapshot.key;
          var childData = childSnapshot.val();
          
         console.log(childData);
         
             var heading = childData.heading;
             var url = childData.url;
             var imageurl = childData.imageurl;
            
            var clickfun = "onclick=event_delete('"+childKey+"')";
          
                  
            
         st = st+1;
  
         $("#tabledtl").append("<tr id='tblrow"+childKey+"'><td>" + st + "</td><td>" + heading + "</td><td>" + url + "</td><td><img src="+ imageurl +" style='width:100px;'></td><td style='width:100px;'><a class='btn btn-success btn-sm' href='"+site_url+"/bloodtip/edit_event?u_Id="+childKey+"'><i class= 'fa fa-edit'></i></a><button "+ clickfun +" class='btn btn-danger btn-sm '><i class='fa fa-trash-o'></i></button></td></tr>");

        //   var row = tableuser.insertRow(rowIndex);

        //   var cellId = row.insertCell(0);
        //   cellId.appendChild(document.createTextNode(childKey));
        
        //   rowIndex = rowIndex + 1;



        });
      
    
    });
     
       
    
   
    function event_delete(key){

      ///var chm = "'"+childKey+"'";  

      //alert(key);

    var uky = key;
   //alert(uky);

   var result = firebase.database().ref().child('NewsEvents/'+uky).remove();


   $('#tblrow'+key).remove();

  

  console.log(result);

  

     alert('Deleted');


    } 
    
    
 
    
    
</script>
