   	

  <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1><?php echo $heading; ?></h1>
         
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">
            <div class="col-md-12">
        <?php if($this->session->flashdata('message')){?>
              
					<div class="alert alert-info alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <h4>	<i class="icon fa fa-check"></i> Message!</h4>
                    <?php echo $this->session->flashdata('message');?>
                  </div>

                        
          <?php } ?>
          <!-- Default box -->
    
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">All Donor List</h3>
            
<!--                <a class="btn btn-success btn-flat pull-right" href="<?php echo site_url('type/CreateType')?>" ><i class="fa fa-plus"></i></a>-->
            </div>
          <table id="tabledtl" class="table table-bordered table-hover table-striped ">
	<tr>
		 <th><b>Sl No.</b></th>
        
        <th>Name</th>
        <th>Mobile</th>
        <th>Gender</th>
        <th>Age</th>
        <th>Blood Group</th>
        <th>Address</th>
        <th>Action</th>
		
	</tr>
	
</table>
            
          </div><!-- /.box -->
          </div><!-- /.box -->
          </div><!-- /.box -->

        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->



<script src="https://www.gstatic.com/firebasejs/4.10.0/firebase.js"></script>
<script>
  // Initialize Firebase
  var config = {
    apiKey: "AIzaSyB3GQCyKLo-PSJpscu1eB9sYG6hwYIo4-I",
    authDomain: "bloodinatip.firebaseapp.com",
    databaseURL: "https://bloodinatip.firebaseio.com",
    projectId: "bloodinatip",
    storageBucket: "bloodinatip.appspot.com",
    messagingSenderId: "808502238432"
  };
  firebase.initializeApp(config);
</script>
<!-- <script src="state_bloodgrp.js"></script> -->

<!--
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/js/bootstrap.min.js" ></script>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>


<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
-->




<script>

//alert('<?php echo $donor_listing;?>');
var site_url = "http://bloodinatip.com/bloodintip_admin/index.php";
var tableuser = document.getElementById("tabledtl");
var databaseRef = firebase.database().ref('Donor/<?php echo $donor_state.'/'.$donor_listing;?>/');

var cunt = 0;

      databaseRef.once('value', function(snapshot) {
        snapshot.forEach(function(childSnapshot) {
          var childKey = childSnapshot.key;
          var childData = childSnapshot.val();
         

         ///var uniq_id = childkey;

          
////var clickfun = 'onclick="dnir_delete("'+childKey+'")"';

var clickfun = "onclick=dnir_delete('"+childKey+"')";

          //alert(chm);

        // console.log(childKey+": "+childSnapshot.val());

        //console.log(childData);

        var encdchky = encodeURIComponent('<?php echo $donor_listing;?>');
         

         var dnr_name = childData.name;
         var dnr_mobl = childData.mobile_no;
         var dnr_gndr = childData.gender;
         var dnr_age = childData.donor_age;
         var dnr_bldgrp = childData.bloodgroup;
         var dnr_addr = childData.address;
         
          cunt = cunt+1;

          
         
         $("#tabledtl").append("<tr id='tblrow"+childKey+"'><td>" + cunt + "</td><td>" + dnr_name + "</td><td>" + dnr_mobl + "</td><td>" + dnr_gndr + "</td><td>" + dnr_age + "</td><td>" + dnr_bldgrp + "</td><td>" + dnr_addr + "</td ><td style='width:100px;'><a href= '"+site_url+"/bloodtip/edit_donor?dnr_st=<?php echo $donor_state;?>&dnr_lst="+encdchky+"&u_Id="+childKey+"' class='btn btn-primary btn-sm'><i class= 'fa fa-edit'></i></a><button "+ clickfun +" class='btn btn-danger btn-sm '><i class='fa fa-trash-o'></i></button></td></tr>");




        //   var row = tableuser.insertRow(rowIndex);

        //   var cellId = row.insertCell(0);
        //   cellId.appendChild(document.createTextNode(childKey));
        
        //   rowIndex = rowIndex + 1;



     




        });
      
    
    });

  
    function dnir_delete(key){

      ///var chm = "'"+childKey+"'";  

      //alert(key);

    var uky = key;
   //alert(uky);

   var result = firebase.database().ref().child('Donor/<?php echo $donor_state.'/'.$donor_listing.'/';?>'+uky).remove();


   $('#tblrow'+key).remove();

  

  console.log(result);

  

     alert('Deleted');


    }

  


</script>
