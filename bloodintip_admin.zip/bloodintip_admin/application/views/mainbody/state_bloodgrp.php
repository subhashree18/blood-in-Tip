   		
  <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1><?php echo $heading; ?></h1>
         
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">
            <div class="col-md-6">
        <?php if($this->session->flashdata('message')){?>
              
					<div class="alert alert-info alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <h4>	<i class="icon fa fa-check"></i> Message!</h4>
                    <?php echo $this->session->flashdata('message');?>
                  </div>


          <?php } ?>
          <!-- Default box -->
    
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">Blood Group</h3>
            
<!--                <a class="btn btn-success btn-flat pull-right" href="<?php echo site_url('type/CreateType')?>" ><i class="fa fa-plus"></i></a>-->
            </div>
          <table id="tabledtl" class="table table-bordered table-hover table-striped ">
	<tr>
		 <th>Sl No</th>
        <th>Blood Group</th>
        <th>View</th>
		
	</tr>
	
</table>
            
          </div><!-- /.box -->
          </div><!-- /.box -->
          </div><!-- /.box -->

        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->





<script src="https://www.gstatic.com/firebasejs/4.10.0/firebase.js"></script>
<script>
  // Initialize Firebase
  var config = {
    apiKey: "AIzaSyB3GQCyKLo-PSJpscu1eB9sYG6hwYIo4-I",
    authDomain: "bloodinatip.firebaseapp.com",
    databaseURL: "https://bloodinatip.firebaseio.com",
    projectId: "bloodinatip",
    storageBucket: "bloodinatip.appspot.com",
    messagingSenderId: "808502238432"
  };
  firebase.initializeApp(config);
</script>
<!-- <script src="state_bloodgrp.js"></script> -->

<!--
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>


<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/js/bootstrap.min.js" ></script>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>


<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
-->



<script>
var site_url = "http://bloodinatip.com/bloodintip_admin/index.php";
var tableuser = document.getElementById("tabledtl");
var databaseRef = firebase.database().ref('Donor/<?php echo $donor_state;?>/');

var count =0;
      databaseRef.once('value', function(snapshot) {

        //console.log(snapshot);

        snapshot.forEach(function(childSnapshot) {
          var childKey = childSnapshot.key;
         //var childData = childSnapshot.val();
  
        /// console.log(childData);
         
         ///console.log(childKey+": "+childSnapshot.val());

        ///console.log(childData);
        
        var encdchky = encodeURIComponent(childKey);

        //alert(encdchky);

         count = count+1;

    $("#tabledtl").append("<tr><td>" + count + "</td><td>" + childKey + "</td><td><a class= 'btn btn-primary' href='"+site_url+"/bloodtip/donor_list?donor_state=<?php echo $donor_state;?>&donor_name="+encdchky+"'>View</a></td></tr>");

        //   var row = tableuser.insertRow(rowIndex);

        //   var cellId = row.insertCell(0);
        //   cellId.appendChild(document.createTextNode(childKey));
        
        //   rowIndex = rowIndex + 1;







        });
      
    
    });


</script>