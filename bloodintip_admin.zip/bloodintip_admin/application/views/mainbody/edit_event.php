   		
  <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>Edit Donor</h1>
         
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">
            <div class="col-md-6">
        <?php if($this->session->flashdata('message')){?>
              
					<div class="alert alert-info alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <h4>	<i class="icon fa fa-check"></i> Message!</h4>
                    <?php echo $this->session->flashdata('message');?>
                  </div>


          <?php } ?>
          <!-- Default box -->
    
          <div class="box">
            <div class="box-header with-border">
<!--              <h3 class="box-title">Edit Donor</h3>-->
            
<!--                <a class="btn bg-purple btn-flat pull-right" href="<?php echo site_url('type')?>" ><i class="fa fa-mail-reply"></i></a>-->
            </div>
          
              <form  id="registr">
                  
              <div class="box-body">
                <div class="form-group">
                    <label for="exampleInputEmail1">Heading<span class="text-red"></span></label>
                   <input type="text" name="heading" id="heading" class="form-control" placeholder="Enter heading">
                </div>
                  
                  
                  
                <div class="form-group">
                  <label for="exampleInputPassword1">Descriptions</label>
                      <textarea class="form-control" name="descriptions" id="descriptions" rows="5" ></textarea>
                  </div>
                  
                    <div class="form-group">
                    <label for="exampleInputEmail1">Event URL<span class="text-red"></span></label>
                   <input type="text" name="url" id="url" class="form-control" placeholder="Enter  URl">
                </div>
                  <p style="color:red"><b>Note:Please enter valid url.</b></p>
                  
                 
                  <div class="form-group">
                    <label for="exampleInputEmail1">Image Upload<span class="text-red"></span></label>
                   <input type="file" name="file_upload" id="file_upload" class="form-control" placeholder="Enter  heading">
                    
                </div>
                  <img id="getimage" src="" style="width:250px"><br/>
                <input type="hidden" id="hideimage" >
                
              
                 
                 
                
                
              </div>
              <!-- /.box-body -->

              <span id="proc" style="color:#DC143C"></span> 
                  
                   <div class="box-footer">
            <button id="submit_frm" type="button" class="btn btn-primary"  >Update</button> 
              </div>
              
             </form>
    
    
              
              
              
              
            
          </div><!-- /.box -->
          </div><!-- /.box -->
          </div><!-- /.box -->

        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->


<script src="https://www.gstatic.com/firebasejs/4.10.0/firebase.js"></script>
<script>
  // Initialize Firebase
  var config = {
    apiKey: "AIzaSyB3GQCyKLo-PSJpscu1eB9sYG6hwYIo4-I",
    authDomain: "bloodinatip.firebaseapp.com",
    databaseURL: "https://bloodinatip.firebaseio.com",
    projectId: "bloodinatip",
    storageBucket: "bloodinatip.appspot.com",
    messagingSenderId: "808502238432"
  };
  firebase.initializeApp(config);
</script>

<script>

 var storage = firebase.storage();

var databaseRef = firebase.database().ref('NewsEvents/<?php echo $ID;?>/');

//var databaseRef = firebase.database().ref('Donor/Odisha/AB+/-L1Bx9E2vLUGK1o_hChu/'); 

      function urlset(snap){
     
     var urlimg =  snap.downloadURL;
     
     
    document.getElementById('hideimage').value = urlimg;
            
           $('#getimage').attr("src",urlimg);
              $("#proc").html('Image upload success');
          
      $("#submit_frm").prop('disabled',false);
          
         
     
 }
 
  
 function image_upload(){
   
    // alert("njxvjkxdnh");
     var filedata = this.files[0];
     $("#proc").html('Image is Uploading..');  
   
      $("#submit_frm").prop('disabled',true); 
     //file storage
      var stordata = storage.ref("Images/" + new Date());
     stordata.put(filedata).then(urlset);
     
 }
 
  file_upload.onchange = image_upload;
 
 

databaseRef.on('value', gotdata);
    

function gotdata(data){

var dnr_dt = data.val();

console.log(dnr_dt);


// databaseRef.on('value', function(data){
       
//        var dnr_dt = data.val();

// console.log(dnr_dt);
//    });

var heading = dnr_dt.heading;
var descriptions = dnr_dt.descriptions;
var eventurl = dnr_dt.url;
var imageurl = dnr_dt.imageurl;


 $("#heading").val(heading);
 $("#descriptions").val(descriptions);
 $("#url").val(eventurl);
 $("#hideimage").val(imageurl);
 $('#getimage').attr("src",imageurl);

}

$('#submit_frm').click(function(){

//    alert('halo');
    
var vheading = $('#heading').val();    
var vdescriptions = $('#descriptions').val();    
var veventurl = $('#url').val();    
var vfile = $('#hideimage').val();    


 if(vheading == ""){
     
     alert('Please enter heading');
     return false;
     
 }else if(veventurl == ""){ 
    
         alert('Please enter Event url');
     return false;  
          
          }else{ 
var uni_ky = '<?php echo $ID;?>' 


var get_dt = {

 descriptions : $('#descriptions').val(),
 heading : $('#heading').val(),
 imageurl : $('#hideimage').val(),
 url : $('#url').val(),
 
 

}

var updates = { };
     updates['NewsEvents/<?php echo $ID;?>'] = get_dt;
    firebase.database().ref().update(updates);

    alert('Updated');
     
 }

});


</script>



</html>