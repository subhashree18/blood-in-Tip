   		
  <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>Edit Donor</h1>
         
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">
            <div class="col-md-6">
        <?php if($this->session->flashdata('message')){?>
              
					<div class="alert alert-info alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <h4>	<i class="icon fa fa-check"></i> Message!</h4>
                    <?php echo $this->session->flashdata('message');?>
                  </div>


          <?php } ?>
          <!-- Default box -->
    
          <div class="box">
            <div class="box-header with-border">
<!--              <h3 class="box-title">Edit Donor</h3>-->
            
<!--                <a class="btn bg-purple btn-flat pull-right" href="<?php echo site_url('type')?>" ><i class="fa fa-mail-reply"></i></a>-->
            </div>
          
              <form  id="registr">
                  
              <div class="box-body">
                <div class="form-group">
                    <label for="exampleInputEmail1">Name<span class="text-red">*</span></label>
                   <input type="text" name="name" id="fname" class="form-control" placeholder="Enter your name">
                </div>
                  
                  
                  
                <div class="form-group">
                  <label for="exampleInputPassword1">Mobile</label>
                  <input type="text" name="phone" id="fphone" class="form-control" placeholder="Enter your phone">
                  </div>
                  
                  
                  <div class="form-group">
                  <label for="exampleInputPassword1">Blood Group</label>
                 <input type="text" name="fblood" id="fblood" class="form-control" placeholder="Enter your blood group">
                  </div>
                  
                  
                  <div class="form-group">
                  <label for="exampleInputPassword1">Age</label>
                  <input type="text" name="age" id="age" class="form-control" placeholder="Enter your age">
                  </div>
                  
                  
                  <div  class="radio">
                  <label for="exampleInputPassword1">Male</label>
                   <input type="radio" name="gendr" id="male" value="MALE">
                  </div>
                  
                  
                  <div  class="radio">
                  <label for="exampleInputPassword1">Female</label>
                    <input type="radio" name="gendr" id="female"value="FEMALE">
                  </div>
                  
                  
                  
                  
                  
                  <div class="form-group">
                  <label for="exampleInputPassword1">Address</label>
                      <textarea class="form-control" name="address" id="address" rows="5" id="comment"></textarea>
                  </div>
                  
                 
                 
                
                
              </div>
              <!-- /.box-body -->

              
             </form>
    
     <div class="box-footer">
            <button id="submit_frm" type="button" class="btn btn-primary"  >Update</button> 
              </div>
              
              
              
              
              
            
          </div><!-- /.box -->
          </div><!-- /.box -->
          </div><!-- /.box -->

        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->


<script src="https://www.gstatic.com/firebasejs/4.10.0/firebase.js"></script>
<script>
  // Initialize Firebase
  var config = {
    apiKey: "AIzaSyB3GQCyKLo-PSJpscu1eB9sYG6hwYIo4-I",
    authDomain: "bloodinatip.firebaseapp.com",
    databaseURL: "https://bloodinatip.firebaseio.com",
    projectId: "bloodinatip",
    storageBucket: "bloodinatip.appspot.com",
    messagingSenderId: "808502238432"
  };
  firebase.initializeApp(config);
</script>
    <!-- <script src="state_bloodgrp.js"></script> -->
    
<!--
    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>


    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/js/bootstrap.min.js" ></script>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>


<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
-->



<?php 

$donor_state = $_GET['dnr_st'];
$donor_listing = $_GET['dnr_lst'];

$ID = $_GET['u_Id'];


?>

<script>



var databaseRef = firebase.database().ref('Donor/<?php echo $donor_state.'/'.$donor_listing.'/'.$ID;?>/');

//var databaseRef = firebase.database().ref('Donor/Odisha/AB+/-L1Bx9E2vLUGK1o_hChu/'); 


databaseRef.on('value', gotdata);
    

function gotdata(data){

var dnr_dt = data.val();

console.log(dnr_dt);


// databaseRef.on('value', function(data){
       
//        var dnr_dt = data.val();

// console.log(dnr_dt);
//    });

var name = dnr_dt.name;
var mobile_no = dnr_dt.mobile_no;
var gender = dnr_dt.gender;
var donor_age = dnr_dt.donor_age;
var bloodgroup = dnr_dt.bloodgroup;
var address = dnr_dt.address;

 $("#fname").val(name);
 $("#fphone").val(mobile_no);
$("#fblood").val(bloodgroup);
$("#age").val(donor_age);
$("#address").val(address);


if(gender == 'MALE'){ 
$('#male').click();

}else{

    $('#female').click();

}



}

$('#submit_frm').click(function(){

//    alert('halo');
    
var vname = $('#fname').val();    
var vmobile_no = $('#fphone').val();    
var vage = $('#age').val();    
var vbloodgroup = $('#fblood').val();    
var vaddress = $('#address').val();    
var vgendr = $('#gendr').val();    

 if(vname == ""){
     
     alert('Please enter name');
     return false;
     
 }else if(vmobile_no == ""){
     
    alert('Please enter phone no.');  
      return false;
     
 }else if(vbloodgroup == ""){
     
    alert('Please enter Blood group');  
      return false;
     
 }else if(vage == ""){
     
     alert('Please enter age');
      return false;

 }else if(vaddress == ""){
     
     alert('Please enter your address');
      return false;
 
 }else if(vgendr == ""){
     
     alert('Please select gender');
      return false;
 }else{ 
    

var uni_ky = '<?php echo $ID;?>' 

var radioValue = $("input[name='gendr']:checked").val();
            // if(radioValue){
            //     alert("Your are a - " + radioValue);
            // }

var get_dt = {

 name : $('#fname').val(),
 mobile_no : $('#fphone').val(),
 donor_age : $('#age').val(),
 bloodgroup : $('#fblood').val(),
 address : $('#address').val(),
 gender : radioValue
 

}

var updates = { };
     updates['Donor/<?php echo $donor_state.'/'.$donor_listing.'/'.$ID;?>' ] = get_dt;
    firebase.database().ref().update(updates);

    alert('Updated');
     
 }

});


</script>



</html>