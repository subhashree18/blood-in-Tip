   	<html>	
  <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>Create Events</h1>
         
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">
            <div class="col-md-6">
        <?php if($this->session->flashdata('message')){?>
              
					<div class="alert alert-info alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <h4>	<i class="icon fa fa-check"></i> Message!</h4>
                    <?php echo $this->session->flashdata('message');?>
                  </div>


          <?php } ?>
          <!-- Default box -->
    
          <div class="box">
            <div class="box-header with-border">
<!--              <h3 class="box-title">Create Events</h3>-->
            
<!--                <a class="btn bg-purple btn-flat pull-right" href="<?php echo site_url('type')?>" ><i class="fa fa-mail-reply"></i></a>-->
            </div>
          
              <form  id="registr">
                  
              <div class="box-body">
                <div class="form-group">
                    <label for="exampleInputEmail1">Heading<span class="text-red"></span></label>
                   <input type="text" name="heading" id="heading" class="form-control" placeholder="Enter  heading">
                </div>
                  
                   <div class="form-group">
                    <label for="exampleInputEmail1">Event URL<span class="text-red"></span></label>
                   <input type="text" name="url" id="url" class="form-control" placeholder="Enter  URl">
                </div>
                <p style="color:red"><b>Note:Please enter valid url.</b></p>
                  
                 
                  <div class="form-group">
                    <label for="exampleInputEmail1">Image Upload<span class="text-red"></span></label>
                   <input type="file" name="file_upload" id="file_upload" class="form-control" placeholder="Enter  heading">
                </div>
                
                <input type="hidden" id="hideimage" >
                
                <div class="form-group">
                  <label for="exampleInputPassword1">Description</label>
                      <textarea class="form-control" name="descriptions" id="descriptions" rows="5" id="comment"></textarea>
                  </div>
                  
              </div>
              <!-- /.box-body -->
 <span id="proc" style="color:#DC143C"></span> 
     <div class="box-footer">
            <button id="submit_evnt" type="button" class="btn btn-primary" onclick= "formsubmit();"  >Submit</button> 
              </div>
              
             </form>
    
              
              
              
              
              
            
          </div><!-- /.box -->
          </div><!-- /.box -->
          </div><!-- /.box -->

        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->


   
<script src="https://www.gstatic.com/firebasejs/4.10.0/firebase.js"></script>
<script>
  // Initialize Firebase
  var config = {
    apiKey: "AIzaSyB3GQCyKLo-PSJpscu1eB9sYG6hwYIo4-I",
    authDomain: "bloodinatip.firebaseapp.com",
    databaseURL: "https://bloodinatip.firebaseio.com",
    projectId: "bloodinatip",
    storageBucket: "bloodinatip.appspot.com",
    messagingSenderId: "808502238432"
  };
  firebase.initializeApp(config);
</script>
</html>
	
<script>
    
    
 var storage = firebase.storage();
    
var uniqky = firebase.database().ref().child("NewsEvents").push().key;
    
    
     function urlset(snap){
     
     var urlimg =  snap.downloadURL;
     
     
    document.getElementById('hideimage').value = urlimg;
            
              $("#proc").html('Image upload success');
      $("#submit_evnt").prop('disabled',false);
       ///  var img_url =  document.getElementById('hideimage').value;
         // console.log(urlimg); 
      //imageurl.push("Imageurl" +urlimg );
 }
 
  
 function image_upload(){
   
    // alert("njxvjkxdnh");
     var filedata = this.files[0];
     $("#proc").html('Image is Uploading..');  
   
      $("#submit_evnt").prop('disabled',true); 
     //file storage
      var stordata = storage.ref("Images/" + new Date());
     stordata.put(filedata).then(urlset);
     
 }
 
  file_upload.onchange = image_upload;
 
 
 
function formsubmit(){
    
    

    var setheading = document.getElementById("heading").value;
    var setdescriptions = document.getElementById("descriptions").value;
    var seturl = document.getElementById("url").value;
       var img_upload =  document.getElementById('hideimage').value;

    
   
//     databaseRef.push().set(setname);
//     databaseRef.push().set(setemail);
//     databaseRef.push().set(setphone);
//     databaseRef.push().set(setmessage);

 var all_dt = {
     
   
    descriptions : setdescriptions,
    heading      :setheading,
    imageurl     :img_upload,
    url          :seturl,
    

 }

 var updates = { };
 updates['/NewsEvents/' + uniqky ] =all_dt;
 firebase.database().ref().update(updates);

 alert('created');

 //reload_page();

}


</script>