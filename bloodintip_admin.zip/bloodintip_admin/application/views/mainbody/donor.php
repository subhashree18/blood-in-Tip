   		
  <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1><?php echo $heading; ?></h1>
         
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">
            <div class="col-md-6">
        <?php if($this->session->flashdata('message')){?>
              
					<div class="alert alert-info alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <h4>	<i class="icon fa fa-check"></i> Message!</h4>
                    <?php echo $this->session->flashdata('message');?>
                  </div>

                        
          <?php } ?>
          <!-- Default box -->
    
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">All State</h3>
            
<!--                <a class="btn btn-success btn-flat pull-right" href="<?php echo site_url('type/CreateType')?>" ><i class="fa fa-plus"></i></a>-->
            </div>
          <table id="tabledtl" class="table table-bordered table-hover table-striped ">
	<tr>
		<th>Sl No.</th>
	
		<th>Donor State</th>
		<th>View</th>
		
	</tr>
	
</table>
            
          </div><!-- /.box -->
          </div><!-- /.box -->
          </div><!-- /.box -->

        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->

<script src="https://www.gstatic.com/firebasejs/4.10.0/firebase.js"></script>
<script>
  // Initialize Firebase
  var config = {
    apiKey: "AIzaSyB3GQCyKLo-PSJpscu1eB9sYG6hwYIo4-I",
    authDomain: "bloodinatip.firebaseapp.com",
    databaseURL: "https://bloodinatip.firebaseio.com",
    projectId: "bloodinatip",
    storageBucket: "bloodinatip.appspot.com",
    messagingSenderId: "808502238432"
  };
  firebase.initializeApp(config);
</script>
<script src="https://bloodinatip.com/bloodintip_admin/assets/js/donor.js"></script>