var tableuser = document.getElementById("tabledtl");
var databaseRef = firebase.database().ref('Donor/');

var site_url = "http://bloodinatip.com/bloodintip_admin/index.php";
var rowIndex = 1;
 
//console.log(databaseRef);

// databaseRef.on("child_added" ,snap => {

//     var donr = snap.val();
     
//       var Donor = snap.child().val();
     
//       console.log(donr);
     

//      donr.forEach(myFunction);

//       function myFunction(value , key){

//         $("#tabledtl").append("<tr><td>" + key + "</td><td><a >view</a></td></tr>");

//       }



var st = 0;

      databaseRef.once('value', function(snapshot) {

       

        snapshot.forEach(function(childSnapshot) {
          var childKey = childSnapshot.key;
         // var childData = childSnapshot.val();
          
         //console.log(childKey);
         
         st = st+1;
  
         $("#tabledtl").append("<tr><td>" + st + "</td><td>" + childKey + "</td><td><a class='btn btn-success' href='"+site_url+"/bloodtip/state_bloodgrp?donor_state="+childKey+"'>View</a></td></tr>");

        //   var row = tableuser.insertRow(rowIndex);

        //   var cellId = row.insertCell(0);
        //   cellId.appendChild(document.createTextNode(childKey));
        
        //   rowIndex = rowIndex + 1;







        });
      
    
    });
     
     